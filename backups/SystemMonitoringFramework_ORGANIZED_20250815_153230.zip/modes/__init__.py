# System Monitoring & Automation Framework
# Modular system for hardware, system, and user activity monitoring